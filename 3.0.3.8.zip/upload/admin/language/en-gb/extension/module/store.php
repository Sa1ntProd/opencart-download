<?php
// Heading
$_['heading_title']    = 'Store';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified store module!';
$_['text_edit']        = 'Edit Store Module';

// Entry
$_['entry_admin']      = 'Admin Users Only';
$_['entry_status']     = 'Status';

//Help
$_['help_admin']       = 'If yes, then multi store list will be visible only when admin user login!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify store module!';