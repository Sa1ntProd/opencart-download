Welcome to the opencart wiki!

1. Introduction
1. Coding Standards
1. OpenCart Structure
1. Library API
1. Extension System
1. Events System
1. Modification System
1. Building a Blog Tutorial

## Introduction
This guide is to give you a better understanding of how to create extensions for OpenCart.
 
In version 3.0 we have added some additional path restrictions so extensions being installed  will not cause issues when uninstalling.
